#!/bin/bash
# Make sure that either this is a brand new host with no data,
# or the data's less than 10 days old.  This avoids resurrecting old deleted rows
# If this is a single-host or test instance, feel free to comment out.
# Will false-positive if commitlogs are removed (such as in case of corruption)
if [[ -d '/opt/cassandra/data/data' && $(/usr/bin/find /opt/cassandra/data/commitlog/ -name 'CommitLog*.log' -mtime -8 | wc -l) -eq 0 ]]; then
  >&2  echo "ERROR:  precheck filed, Cassandra data too old"
  exit 10
fi

