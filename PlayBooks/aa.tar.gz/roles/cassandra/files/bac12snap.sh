#!/bin/bash
/usr/local/bin/mcnodetool snapshot -t bac12-$(/bin/date +%Y%m%d-%H%M) --column-family xxx yyyy  &> /dev/null

