#!/bin/bash
set -eu
set -x

CASSANDRA_DIR=/opt/cassandra_data
NODETOOL=/usr/local/bin/mcnodetool
STAGINGDIR=/opt/cassandrabackup/snapshots
S3BUCKET=mcbackup_cassandra

HOSTNAME=$(/bin/hostname)
BACKUPTIME=$(/bin/date +%Y%m%d-%H%M)

echo "Starting snapshot"
$NODETOOL snapshot -t $BACKUPTIME

echo "Cleaning up staging dir"
/bin/rm -f $STAGINGDIR/*.tar.mc2 || true
/bin/rm -f $STAGINGDIR/*.tar.mc2.mcff || true
/bin/rm -f $STAGINGDIR/*.tar.mc2.[0-9][0-9] || true
/bin/rm -f $STAGINGDIR/*.tar.mc2.[0-9][0-9].mcff || true

for keyspace in $(ls $CASSANDRA_DIR/data | grep -v 'OpsCenter'); do
    for tabledir in $(ls $CASSANDRA_DIR/data/$keyspace/); do
        table=$(echo $tabledir | cut -d- -f1)
        backupsource="$CASSANDRA_DIR/data/$keyspace/$tabledir/snapshots/$BACKUPTIME/"
        backupfilename="$(/bin/hostname)-$keyspace-$table-$BACKUPTIME.tar.mc2"
        if [ ! -d $backupsource ]; then
            echo "$tabledir has no snapshots, skipping it"
            continue
        fi
	# Using bsdtar instead of GNU.  Cassandra sometimes removes the original db
	# file that we snapshotted, which updates the hardlink's ctime, which
	# causes GNU tar to freak out.
        filesize_guess=$(du -bs $backupsource | awk '{print $1}')
        s3backupdest="s3://$S3BUCKET/$(/bin/hostname)-$keyspace-$table-$BACKUPTIME.tar.mc2.gpg"
        echo "Tarring up $backupsource  and copying to S3 $s3backupdest"
        attempts=1
        until /usr/bin/bsdtar -c -f - -C $backupsource . | /usr/bin/nice /usr/bin/pmcip2 -p4 | /usr/bin/gpg --encrypt --trust-model always -r mccassandra@mastercard.com -z0 | /usr/local/bin/aws --profile cassandrabackup s3 cp --expected-size $filesize_guess - $s3backupdest; do
            (( $attempts >= 20 )) && exit 1
            echo "Transfer failed, retrying in 30s"
            sleep 30
            attempts=$(( attempts + 1 ))
        done
    done
done
# Once everything's totally successfully done, create a "done" file
# that we can use for monitoring
echo "$BACKUPTIME" > $STAGINGDIR/donefile_${HOSTNAME}
/usr/local/bin/aws --profile cassandrabackup s3 cp $STAGINGDIR/donefile_${HOSTNAME} s3://$S3BUCKET/

echo "Removing snapshot $BACKUPTIME"
$NODETOOL clearsnapshot -t $BACKUPTIME
