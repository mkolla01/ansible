#!/bin/bash
set -eu
set -o pipefail
set -x

COMMITLOG_ARCHIVE_DIR=/opt/cassandra/commitlog_archive
NODETOOL=/usr/local/bin/mcnodetool
S3BUCKET=mcbackup-cassandra-commitlog

HOSTNAME=$(/bin/hostname)
BACKUPTIME=$(/bin/date +%Y%m%d-%H%M)


for commitlog_file in $(ls $COMMITLOG_ARCHIVE_DIR ); do
    backupsource="$COMMITLOG_ARCHIVE_DIR/$commitlog_file"
    echo "Tarring up $commitlog_file and copying to S3"
    s3backupdest="s3://$S3BUCKET/$(/bin/hostname)-$commitlog_file-$BACKUPTIME.mc2.gpg"
    attempts=1
    until cat $backupsource | mcip2 | /usr/bin/gpg --encrypt --trust-model always -r mccassandra@mastercard.com -z0 | /usr/local/bin/aws --profile cassandrabackup s3 cp - $s3backupdest; do
    (( $attempts >= 20 )) && exit 1
        echo "Transfer failed, retrying in 30s"
        sleep 30
        attempts=$(( attempts + 1 ))
    done
    echo "cleaning up $backupsource"
    /bin/rm $backupsource
done

