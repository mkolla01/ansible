#!/usr/bin/env python

## {{ ansible_managed }} ##

import datetime
from boto3.session import Session
from pyzabbix import ZabbixMetric, ZabbixSender

hostname = '{{ ansible_hostname }}'
donefile_name = 'donefile_' + hostname

session = Session(profile_name='cassandrabackup')
s3 = session.resource('s3')
backup_bucket =  [x for x in s3.buckets.all() if x.name=='mcbackup_cassandra'][0]
file_list = list(backup_bucket.objects.all())
try:
  donefile_timestamp = [file.get()['Body'].read() for file in file_list if file.key == donefile_name][0].strip()
except:
  donefile_timestamp = '20000101-0000'
backup_filesizes = [file.size for file in file_list if donefile_timestamp in file.key and hostname in file.key]
backup_totalsize = sum(backup_filesizes) / 1024 / 1024
backup_filecount = len(backup_filesizes)

year = int(donefile_timestamp[0:4])
month = int(donefile_timestamp[4:6])
day = int(donefile_timestamp[6:8])
hour = int(donefile_timestamp[9:11])
minute = int(donefile_timestamp[11:13])
backup_age =  datetime.datetime.now() - datetime.datetime(year, month, day, hour, minute)
backup_age_hours = backup_age.total_seconds() / 60 / 60

zabbix_data = [
        ZabbixMetric(hostname, 'cassandra.backupAgeHours', backup_age_hours),
        ZabbixMetric(hostname, 'cassandra.backupSizeMbytes', backup_totalsize),
        ZabbixMetric(hostname, 'cassandra.backupSizeFilecount', backup_filecount),
        ]


ZabbixSender("{{ zabbixProxy | default('monitor-sac0-0000') }}", 10051).send(zabbix_data)
