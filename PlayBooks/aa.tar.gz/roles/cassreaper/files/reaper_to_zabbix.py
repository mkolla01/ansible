#!/usr/bin/env python3
"""
"""

import requests
import datetime
from pyzabbix import ZabbixMetric, ZabbixSender

def fetch_data_from_reaper():
    response = requests.get('http://localhost:8080/repair_run?state=DONE')
    if response.status_code != 200:
        print("Unable to contact Prometheus!")
        exit(5)

    repair_runs = response.json()
    return repair_runs

def clusters_from_reaper_data(reaper_data):
    return list(set([x['cluster_name'] for x in reaper_data if x['state'] == 'DONE']))

def cassandra_cluster_to_zabbix_host(cassandra_clustername):
    cluster_suffix = cassandra_clustername.split('-')[1:][0]
    return "cassandra_" + cluster_suffix

def reaper_time_to_timestamp(java_time):
    # Java calls UTC 'Z', I think for offset Zero
    # converting to 'UTC' rather than stripping, in case it's run on something not in UTC some day
    java_time = java_time.replace('Z', 'UTC')
    python_datetime = datetime.datetime.strptime(java_time, '%Y-%m-%dT%H:%M:%S%Z')
    return int(python_datetime.timestamp())

def reaper_runs_to_last_repairs(reaper_data):
    last_repairs = {}
    for repair_dict in reaper_data:
        repair_cluster_keyspace = "%s_%s" % (repair_dict['cluster_name'], repair_dict['keyspace_name'])
        repair_unixtime = reaper_time_to_timestamp(repair_dict['end_time'])
        if repair_cluster_keyspace not in last_repairs or last_repairs[repair_cluster_keyspace]['time'] < repair_unixtime:
            last_repairs[repair_cluster_keyspace] = {
                'cluster': repair_dict['cluster_name'],
                'keyspace': repair_dict['keyspace_name'],
                'time': repair_unixtime,
            }
    return last_repairs

def send_to_zabbix(last_repairs):
    zabbix_data = []
    for last_repair in last_repairs:
        zabbix_data.append(ZabbixMetric(
          cassandra_cluster_to_zabbix_host(last_repairs[last_repair]['cluster']),
          "cassandra." + last_repairs[last_repair]['keyspace'] + ".repaired",
          last_repairs[last_repair]['time'])
        )
    return ZabbixSender('monitor-sac0-0000', 10051).send(zabbix_data)

def main():
    reaper_runs = fetch_data_from_reaper()
    last_repairs = reaper_runs_to_last_repairs(reaper_runs)
    res = send_to_zabbix(last_repairs)
#    print(res)

if __name__ == '__main__':
        main()

